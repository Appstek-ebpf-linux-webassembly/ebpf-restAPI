package main

import (
	//"fmt"
	//"io/ioutil"
	"log"
	"os"
	"github.com/gin-gonic/gin"
)

type Policy struct {
    Ip    string
    Port string
}

func sendToeBPF(filePath string , content Policy){
    //Append second line
    file, err := os.OpenFile(filePath, os.O_APPEND|os.O_WRONLY, 0644)
    if err != nil {
        log.Println(err)
    }
    defer file.Close()
    if _, err := file.WriteString(content.Ip+"\n"); err != nil {
        log.Fatal(err)
    }
  
}
func SetUpRouter() *gin.Engine{
    router := gin.Default()
    return router
}
var req Policy
func creatPolicy(c *gin.Context){
    
        c.BindJSON(&req)
	
        c.JSON(200, req)
	sendToeBPF(".././tmp/Policy.txt", req)


}
func main() {
    //r := gin.Default()
    r:=SetUpRouter()
    
    r.POST("Post/", creatPolicy)
    r.Run(":8080")
   
}