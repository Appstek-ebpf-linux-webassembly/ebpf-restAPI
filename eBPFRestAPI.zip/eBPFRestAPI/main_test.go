package main
import (
	"net/http"
	"net/http/httptest"
	"testing"
	"bytes"
        "encoding/json"
	"github.com/stretchr/testify/assert"
)

func TestNewCompanyHandler(t *testing.T) {
	r := SetUpRouter()
	r.POST("/", creatPolicy)
	p := Policy{
	    Ip: "192.168.0.10",
	    Port: "2002",
	    }
	jsonValue, _ := json.Marshal(p)
	req, _ := http.NewRequest("POST", "/", bytes.NewBuffer(jsonValue))
    
	w := httptest.NewRecorder()
	r.ServeHTTP(w, req)
	assert.Equal(t, http.StatusOK, w.Code)
    }